import React, { useEffect, useState } from "react";
import { LeftMenu } from "./Utils";
import axios from "../../utils/axios_util";
import Loader from "../Loader";

const InputCourse = ({ user, setUser }) => {
	const [error, setError] = useState("");
	const [success, setSuccess] = useState("");
	const [loading, setLoading] = useState(false);
	const [availableCourses, setAvailableCourses] = useState([]);
	const [courseDetails, setCourseDetails] = useState({
		courseName: "",
		courseInstructor: "",
		courseCode: "",
		courseCapacity: 0,
	});

	useEffect(() => {
		const fetchCourseNames = async () => {
			try {
				setLoading(true);
				setError("");
				const response = await axios.get("/api/get-all-courses", {
					headers: {
						Authorization: localStorage.getItem("token"),
					},
				});

				if (response.status === 200) {
					setAvailableCourses(response.data.courses);
				} else {
					setError("Failed to fetch courses");
					console.error("Failed to fetch courses:", response);
				}
			} catch (err) {
				setError("Failed to fetch courses");
				console.error("Error fetching courses:", err);
			}
			 finally {
				setLoading(false);
			 }
		};

		// Call the function to fetch course names when the component mounts
		fetchCourseNames();
	}, []);

	const handleChange = (e) => {
		const { name, value } = e.target;
		setCourseDetails((prevState) => ({
			...prevState,
			[name]: value,
		}));
	
	}

	const handleSubmit = async (e) => {
		e.preventDefault();
		e.stopPropagation();

		// validate form fields
		if (!courseDetails.courseName) {
			setError("Course Name is required");
			return;
		}
		if (!courseDetails.courseInstructor) {
			setError("Course Instructor is required");
			return;
		}
		if (!courseDetails.courseCode) {
			setError("Course Code is required");
			return;
		}
		if (!courseDetails.courseCapacity) {
			setError("Course Capacity is required");
			return;
		}

		setError("");
		setLoading(true);
		axios.post("/api/add-course", { ...courseDetails }, {
			headers: {
				Authorization: localStorage.getItem("token"),
			}
		}).then((response) => {
			if (response.status === 201) {
				setSuccess("Course added successfully");
				const newAvailableCourses = [...availableCourses, courseDetails];
				setAvailableCourses(newAvailableCourses);
				setCourseDetails({
					courseName: "",
					courseInstructor: "",
					courseCode: "",
					courseCapacity: 0,
				});
			} else {
				setError("Failed to add the course");
				console.error("Failed to add the course:", response);
			}
		}).catch((err) => {
			setError("Failed to add the course");
			console.error("Error adding course:", err);
		}).finally(() => {
			setLoading(false);
		});
	};

	const deleteCourse = (id) => {
		// confirm before deleting
		if (!window.confirm("Are you sure you want to delete this course?")) {
			return;
		}

		setLoading(true);
		setError("");
		setSuccess("");
		axios.delete(`/api/delete-course/${id}`, {
			headers: {
				Authorization: localStorage.getItem("token"),
			}
		}).then((response) => {
			if (response.status === 200) {
				const newAvailableCourses = availableCourses.filter((course) => course.id !== id);
				setAvailableCourses(newAvailableCourses);
				setSuccess("Course deleted successfully");
			} else {
				setError("Failed to delete course");
			}
		}).catch((err) => {
			setError("Failed to delete course");
			console.error("Error deleting course:", err);
		}).finally(() => {
			setLoading(false);
		});
	}

	return (
		<div>
			{loading && <Loader />}
			<div className="add-form-container">
				<LeftMenu user={user} setUser={setUser} />
				<div className="menu-right-container">
					<div className="mb-3">
						{error && 
						<div className="alert alert-danger" role="alert">
							{error}
						</div>}
						{success && 
						<div className="alert alert-success" role="alert">
							{success}
						</div>}
					</div>
					<form method="post" onSubmit={handleSubmit}>
						<h1>Add Course</h1>
						<hr/>
						<div className="row">
							<div className="col-6">
								<div className="mb-3">
									<label htmlFor="courseName" className="form-label">
										Course Name
									</label>
									<input type="text" className="form-control" id="courseName" name="courseName"
										value={courseDetails.courseName} onChange={handleChange} />
								</div>
							</div>
							<div className="col-6">
								<div className="mb-3">
									<label htmlFor="courseInstructor" className="form-label">
										Course Instructor
									</label>
									<input type="text" className="form-control" id="courseInstructor" name="courseInstructor"
										value={courseDetails.courseInstructor} onChange={handleChange} />
								</div>
							</div>
						</div>
						<div className="row">
							<div className="col-6">
								<div className="mb-3">
									<label htmlFor="courseCode" className="form-label">
										Course Code
									</label>
									<input type="text" className="form-control" id="courseCode" name="courseCode"
										value={courseDetails.courseCode} onChange={handleChange} />
								</div>
							</div>
							<div className="col-6">
								<div className="mb-3">
									<label htmlFor="courseCapacity" className="form-label">
										Course Capacity
									</label>
									<input type="number" min={1} className="form-control" id="courseCapacity" name="courseCapacity"
										value={courseDetails.courseCapacity} onChange={handleChange}/>
								</div>
							</div>
						</div>
						<button type="submit" className="btn btn-primary w-100">
							Submit
						</button>
					</form>

					<div className="mt-5">
						<h1>Available Course Names</h1>
						<hr/>
						{availableCourses.length !== 0 && (
							<table className="table table-striped table-bordered">
								<thead>
									<tr>
									<th>Course Capacity</th>
										<th>Course Name</th>
										<th>Course Instructor</th>
										<th>Course Code</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								{availableCourses.map((courseDetails, index) => (
									<tr key={index}>
										<td>{courseDetails.courseCode}</td>
										<td>{courseDetails.courseCapacity}</td>
										<td>{courseDetails.courseName}</td>
										<td>{courseDetails.courseInstructor}</td>
										<td>
											<button type="button" className="btn btn-danger"
												onClick={e => deleteCourse(courseDetails.id)}>
												Delete
											</button>
										</td>
									</tr>
								))}									
								</tbody>
							</table>
						)}
						{availableCourses.length === 0 &&
						<div className="alert alert-warn" role="alert">
							No courses available
						</div>}
					</div>
				</div>
			</div>
		</div>
	);
};

export default InputCourse;
