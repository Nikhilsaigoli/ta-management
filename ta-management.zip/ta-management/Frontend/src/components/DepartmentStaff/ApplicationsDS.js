import "@fontsource/roboto/300.css";
import "@fontsource/roboto/400.css";
import "@fontsource/roboto/500.css";
import "@fontsource/roboto/700.css";
import { useEffect, useRef, useState } from "react";
import axios from "../../utils/axios_util";
import { LeftMenu } from "./Utils";
import Loader from "../Loader";

const CourseChip = ({ course, index, onToggle, isSelected }) => {
	let className = "btn btn-secondary mr-3 position-relative";
	if (isSelected) {
		className = "btn btn-success mr-3 position-relative";
	}
	return (
		<button key={index} className={className} onClick={e => onToggle(course)}>
			{course}
		</button>
	);
};

const PreviousTAChip = (props) => {
	return (
		<button className="btn btn-secondary mr-3 position-relative" key={props.index}>{props.course}</button>
	);
};

const ConfirmationModal = ({ open, onClose, onConfirm }) => {
	const btnRef = useRef(null);
	useEffect(() => {
		if (open && btnRef.current) {
			btnRef.current.click();
		}
	}, [open]);

	return (
		<div>
			{open &&
			<div className="confirmation-modal">
				<div className="modal-background"></div>
				<div className="modal-content">
					<div className="modal-header">
						<h5 className="modal-title">Confirm Recommendation</h5>
					</div>
					<div className="modal-body">
						<p>Are you sure you want to recommend this applicant to the TA Committee with the selected courses?</p>
					</div>
					<div className="modal-footer">
						<button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={onClose}>No, go back</button>
						<button type="button" className="btn btn-primary" onClick={onConfirm}>Yes, confirm</button>
					</div>
				</div>
			</div>}
		</div>
	);
};

const ApplicationCard = ({
	application,
	setApplications,
	index,
	setError,
	setSuccess,
	setLoading,
}) => {
	const [openConfirmation, setOpenConfirmation] = useState(false);
	const [applicantIdToReview, setApplicantIdToReview] = useState(null);

	const handleReview = (applicantId) => {
		if (application.DSCourses.length === 0) {
			setError("Please select at least one course to recommend");
			return;
		}
		setApplicantIdToReview(applicantId);
		setOpenConfirmation(true);
	};

	const confirmReview = () => {
		setOpenConfirmation(false);
		setError("");
		setSuccess("");
		setLoading(true);
		axios.put(`/api/updateApplicant/${applicantIdToReview}`, {
			...application,
			review: true,
			status: application.status.map((st) => {
				if (st === "Pending") {
					return "Rejected";
				}
				return st;
			}),
		}, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			}
		}).then((response) => {
			setApplications((prevApplications) =>
				prevApplications.map((applicant) => {
					if (applicant.id === applicantIdToReview) {
						return {
							...applicant,
							review: true,
						};
					}
					return applicant;
				}));
			setSuccess("Application recommended successfully");
		}).catch((error) => {
			setError("Error recommending the application");
			console.error("Error recommending the application:", error);
		}).finally(() => {
			setLoading(false);
		});
	};

	const toggleCourseSelection = (course) => {
		setApplications((prevApplications) => {
			const newApplications = [...prevApplications];
			const targetedApplication = newApplications[index];
			const courseIndex = targetedApplication.DSCourses.indexOf(course);
			const cIndex2 = targetedApplication.eligibleCourses.indexOf(course);
			if (courseIndex > -1) {
				targetedApplication.DSCourses.splice(courseIndex, 1);
				targetedApplication.status[cIndex2] = "Pending";
			} else {
				targetedApplication.DSCourses.push(course);
				targetedApplication.status[cIndex2] = "In Review";
			}
			newApplications[index] = { ...targetedApplication };
			return newApplications;
		});
	};

	const handleSave = (applicationId, updatedData) => {
		setError("");
		setSuccess("");
		setLoading(true);
		axios.put(`/api/updateApplicant/${applicationId}`, updatedData, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			},
		}).then((response) => {
			setSuccess("Application saved successfully");
		}).catch((error) => {
			setError("Error saving application");
			console.error("Error saving application:", error);
		}).finally(() => {
			setLoading(false);
		});
	};

	const downloadFile = (filename) => {
		setError("");
		setSuccess("");
		setLoading(true);
		filename = filename.split("/")[1];
		axios.get(`/api/download-resume/${filename}`, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			},
			responseType: "blob",
		}).then((response) => {
			const file = new Blob([response.data], {
				type: "application/octet-stream",
			});
	
			const downloadUrl = window.URL.createObjectURL(file);
			const link = document.createElement("a");
			link.href = downloadUrl;
			link.setAttribute("download", `${application.name}-resume.pdf`);
			document.body.appendChild(link);
			link.click();
	
			link.parentNode.removeChild(link);
			window.URL.revokeObjectURL(downloadUrl);
		}).catch((error) => {
			setError("Error downloading file");
			console.error("Error downloading file:", error);
		}).finally(() => {
			setLoading(false);
		});
	}

	return (
		<div className="accordion-item">
			<h2 className="accordion-header">
				<button className="accordion-button collapsed w-100" type="button" data-bs-toggle="collapse"
					data-bs-target={`#collapse${index}`} aria-expanded="true" aria-controls={`collapse${index}`}>
					<div className="d-flex align-center justify-content-between w-100 mr-3">
						<div>
							{application.name} ({application.email}) | #{application.znumber}
						</div>
					</div>
				</button>
			</h2>
			<div id={`collapse${index}`} className="accordion-collapse collapse" data-bs-parent="#applicationsAccordian">
				<div className="accordion-body">
					<div>
						<button className="btn btn-primary" onClick={() => downloadFile(application.resume)}>
							Resume
						</button>
						<button className="btn btn-success ms-2" onClick={() => handleReview(application.id)}
							disabled={application.review}>
							{`${application.review ? "Recommended" : "Recommend"}`}
						</button>
						<hr />
					</div>
					<ConfirmationModal open={openConfirmation} onClose={() => setOpenConfirmation(false)}
						onConfirm={confirmReview} />
					<div className="mt-3 border p-3">
						<p>Select courses to recommend to TA Committee</p>
						<hr />
						{application.eligibleCourses?.map((course, index) => {
							return (
								<CourseChip course={course} index={index} onToggle={toggleCourseSelection}
									isSelected={application.DSCourses?.includes(course)} key={index} />
							);
						})}
					</div>
					<div className="mt-3 border p-3 mb-3">
						<p>Previous Teaching Assistant Courses</p>
						<hr />
						{application.previousTACourses?.map((course, index) => {
							return (
								<PreviousTAChip course={course} index={index} key={index} />
							);
						})}
					</div>
					{!application.review && (
						<button className="btn btn-success w-100" onClick={() => handleSave(application.id, application)}>
							Save
						</button>
					)}
				</div>
			</div>
		</div>);
};

const ApplicationsDS = ({ setUser, user }) => {
	const [applications, setApplications] = useState([]);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");
	const [success, setSuccess] = useState("");

	useEffect(() => {
		axios.get("/api/getApplicants", {
			headers: {
				Authorization: localStorage.getItem("token"),
			},
		}).then((response) => {
			if (response.status === 200) {
				setApplications(response.data);
			} else {
				setError("Failed to fetch applicants");
				console.error("Failed to fetch applicants:", response.statusText);
			}
		}).catch(err => {
			setError("Failed to fetch applicants");
			console.error("Error fetching applicants:", err);
		}).finally(() => {
			setLoading(false);
		});
	}, []);

	return (
		<div>
			{loading && <Loader />}
			<div>
				<LeftMenu user={user} setUser={setUser} />
				<div className="menu-right-container">
					{error &&
						<div className="alert alert-danger" role="alert">
							{error}
						</div>}
					{success &&
						<div className="alert alert-success" role="alert">
							{success}
						</div>}
					<h1>All Applicants</h1>
					<hr />
					{applications.length !== 0 &&
						<div className="accordion" id="applicationsAccordian">
							{applications.map((application, index) => {
								return (
									<ApplicationCard
										application={application}
										setApplications={setApplications}
										index={index}
										key={index}
										setError={setError}
										setSuccess={setSuccess}
										setLoading={setLoading}
									/>
								);
							})}
						</div>}
					{!applications.length &&
						<div className="alert alert-warning" role="alert">
							No applications found
						</div>}
				</div>
			</div>
		</div>
	);
};

export default ApplicationsDS;
