import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Loader from "./Loader";
import axios from "../utils/axios_util";
import '../styles/Login.css';

const Login = ({ setUserGlobal }) => {
	const navigate = useNavigate();
	const [credentials, setCredentials] = useState({
		username: "",
		password: "",
	});

	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);

	useEffect(()=> {
		let startBtn = document.getElementById("start-btn");
		if (startBtn) {
			startBtn.click();
		}
	}, []);

	const handleSignIn = (event) => {
		// prevent default form submission
		event.preventDefault();
		event.stopPropagation();

		// clear fields before request
		setError("");
		// check if al fields are provided
		if (!credentials.username) {
			setError("Username is required");
			return;
		}

		if (!credentials.password) {
			setError("Password is required");
			return;
		}

		// make requests
		setLoading(true);
		setError("");
		axios
			.post("/api/login", {
				username: credentials.username,
				password: credentials.password,
			})
			.then((res) => {
				localStorage.setItem("token", res.data.token);
				setUserGlobal({ username: res.data.username, role: res.data.role });
				navigate("/");
			})
			.catch((err) => {
				console.log(err);
				if (err.response && err.response.data) {
					setError(err.response.data);
				} else if (err.message) {
					setError(err.message);
				} else {
					setError("An error occurred. Please try again later");
				}
			})
			.finally(() => {
				setLoading(false);
			});
	};

	return (
		<div className="wrapper-container">
			<div id="particles-js"></div>
			{loading && <Loader />}
			<div className="login-container">
				{error &&
				<div className="alert alert-danger fade show" role="alert">
					{error}
				</div>}

				<h1>TA Management</h1>
				<div className="signInContainer">
					<h1>Sign In</h1>
					<hr/>
					<form onSubmit={handleSignIn} method="post" action="/api/login">
						<div className="mb-3">
							<label htmlFor="username" className="form-label">Username</label>
							<input type="text" className="form-control" placeholder="Username"
								name="username" id="username" value={credentials.username}
								onChange={e => setCredentials(credentials => {
									return {
										...credentials,
										username: e.target.value
									}
								})} />
						</div>
						<div className="mb-3">
							<label htmlFor="password" className="form-label">Password</label>
							<input type="password" className="form-control" id="password" name="password"
								placeholder="Password"
								value={credentials.password}
								onChange={e => setCredentials(credentials => {
									return {
										...credentials,
										password: e.target.value
									}
								})} />
						</div>
						<button type="submit" className="btn btn-primary">Sign In</button>
					</form>
					<p className="mt-3">Don't have an account? <a href="/signup" onClick={e => {
						e.preventDefault();
						navigate("/signup");
					}}>Sign Up</a></p>
				</div>
			</div>
		</div>
	);
};

export default Login;
