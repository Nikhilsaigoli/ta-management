import React, { useEffect, useState } from "react";
import { LeftMenu } from "./Utils";
import axios from "../../utils/axios_util";
import Loader from "../Loader";

const FeedbackList = ({ user, setUser }) => {
	const [feedbacks, setFeedbacks] = useState([]);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");

	useEffect(() => {
		axios.get(`/api/getFeedbacks/${user.username}`, {
			headers: {
				Authorization: localStorage.getItem("token"),
			},
		}).then((response) => {
			if (response.status === 200) {
				setFeedbacks(response.data);
			} else {
				setError("Failed to fetch feedbacks");
				console.error("Failed to fetch feedbacks:", response.statusText);
			}
		}).catch((err) => {
			setError("Failed to fetch feedbacks");
			console.error("Error fetching feedbacks:", err);
		}).finally(() => {
			setLoading(false);
		});
	}, [user.username]);

	return (
		<div>
			{loading && <Loader />}
			<div>
				<LeftMenu user={user} setUser={setUser} />
				<div className="menu-right-container">
					<div>
						{error &&
						<div className="alert alert-danger" role="alert">
						{error}
					  </div>}
					</div>
					<div>
						<h1>All Feedbacks</h1>
						<hr />
						<div>							
							{feedbacks.length !== 0 && 
							<div>
								{feedbacks.map((feedback, index) => {
									return (
										<div className="feedback-card">
											<div>												
												<div className="d-flex align-center">
													<img src="https://www.w3schools.com/howto/img_avatar.png" alt="Avatar" className="avatar" />
													<div>
														<h4 className="m-0">{feedback.name}</h4>
														<p className="m-0">{feedback.username} ({feedback.email})</p>
													</div>
												</div>
												<div className="rating">
													{[...Array(feedback.rating)].map((star, index) => {
														return <i className="fa-solid fa-star" key={index}></i>;
													})}
												</div>
											</div>
											<hr/>
											<p>{feedback.feedback}</p>
										</div>
									);
								})}
							</div>}
							{!feedbacks.length &&
							<div className="alert alert-warning" role="alert">
								No Feedbacks Yet
							</div>}
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default FeedbackList;
