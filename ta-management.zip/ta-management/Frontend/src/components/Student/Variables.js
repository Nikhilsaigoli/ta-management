export const allPreviousCourses = [
    "Algorithms",
    "Artificial Intelligence",
    "Computer Architecture",
    "Computer Graphics",
    "Computer Networks",
    "Computer Organization",
    "Computer Security",
    "Computer Vision",
    "Cryptography",
    "Data Structures",
    "Database Systems",
    "Deep Learning",
    "Discrete Mathematics",
    "Machine Learning",
    "Operating Systems",
    "Software Engineering"
];
