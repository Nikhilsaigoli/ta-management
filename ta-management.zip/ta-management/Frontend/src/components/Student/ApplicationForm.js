import React, { useEffect, useState } from "react";
import axios from "../../utils/axios_util";
import { LeftMenu } from "./Utils";
import { allPreviousCourses } from "./Variables";
import Loader from "../Loader";

const ApplicationForm = ({ setUser, user }) => {
	const [preCourse, setPreCourse] = useState(false);
	const [availableCourses, setAvailableCourses] = useState([]);
	const [previousCourses, setPreviousCourses] = useState([""]);
	const [eligibleCourses, setEligibleCourses] = useState([""]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [success, setSuccess] = useState("");
	const [formData, setFormData] = useState({
		username: user.username,
		znumber: "",
		name: "",
		email: "",
		phoneNumber: "",
		joiningDate: "",
		previousCourses: [],
		eligibleCourses: [],
		resume: null,
	});

	useEffect(() => {
		axios.get("/api/get-all-courses", {
			headers: {
				Authorization: localStorage.getItem("token"),
			},
		}).then((response) => {
			if (response.status === 200) {
				let courses = response.data.courses;
				courses.sort();
				setAvailableCourses(courses);
			} else {
				setError("Failed to fetch available courses");
				console.error("Failed to fetch courses:", response.statusText);
			}
		}).catch((error) => {
			setError("Failed to fetch available courses");
			console.error("Failed to fetch courses:", error);
		}).finally(() => {
			setLoading(false);
		});
	}, []);

	const handleChange = (event) => {
		const { name, value } = event.target;
		setFormData((prevState) => ({
			...prevState,
			[name]: value,
		}));
	};

	const handlePreviousCourseChange = (event, index) => {
		const { value } = event.target;
		const newPreviousCourses = [...previousCourses];
		newPreviousCourses[index] = value;
		setPreviousCourses(newPreviousCourses);
		setFormData({
			...formData,
			previousCourses: newPreviousCourses,
		});
	};

	const handleEligibleCourseChange = (event, index) => {
		const { value } = event.target;
		const newEligibleCourses = [...eligibleCourses];
		newEligibleCourses[index] = value;
		setEligibleCourses(newEligibleCourses);
		setFormData({
			...formData,
			eligibleCourses: newEligibleCourses,
		});
	};

	const handleFileChange = (event) => {
		setFormData((prevState) => ({
			...prevState,
			resume: event.target.files[0],
		}));
	};

	function validateForm() {
		if (!formData.znumber) {
			return "Z-Number is required";
		}

		if (!formData.name) {
			return "Name is required";
		}

		if (!formData.email) {
			return "Email is required";
		} else if (!/\S+@\S+\.\S+/.test(formData.email)) {
			return "Invalid email address";
		}

		if (!formData.phoneNumber) {
			return "Phone number is required";
		} else if (!/^\d{10}$/.test(formData.phoneNumber)) {
			return "Invalid phone number format";
		}

		if (!formData.joiningDate) {
			return "Joining date is required";
		}

		if (formData.eligibleCourses.length === 0) {
			return "Eligible courses are required";
		}

		if (formData.eligibleCourses.includes("Select Course") || formData.eligibleCourses.includes("")) {
			return "Select a valid eligible course";
		}

		if (formData.previousCourses.includes("Select Course") || formData.previousCourses.includes("")) {
			return "Select a valid previous course";
		}

		if (!formData.resume) {
			return "Resume is required";
		}

		return "";
	}

	const handleSubmit = (event) => {
		setError("");
		setSuccess("");
		event.preventDefault();
		event.stopPropagation();

		const errorMsg = validateForm();
		if (errorMsg !== "") {
			setError(errorMsg);
			return;
		}

		const data = new FormData();
		data.append("username", formData.username);
		data.append("znumber", formData.znumber);
		data.append("name", formData.name);
		data.append("email", formData.email);
		data.append("phoneNumber", formData.phoneNumber);
		data.append("joiningDate", formData.joiningDate);
		data.append("previousCourses", JSON.stringify(formData.previousCourses));
		data.append("eligibleCourses", JSON.stringify(formData.eligibleCourses));
		if (formData.resume) {
			data.append("resume", formData.resume);
		}

		setLoading(true);
		axios.post("/api/submitApplication", data, {
			headers: {
				"Content-Type": "multipart/form-data",
				"Authorization": localStorage.getItem("token"),
			},
		}).then(() => {
			setFormData({
				username: user.username,
				znumber: "",
				name: "",
				email: "",
				phoneNumber: "",
				joiningDate: "",
				previousCourses: [],
				eligibleCourses: [],
				resume: null,
			});
			setEligibleCourses([""]);
			setPreviousCourses([""]);
			setSuccess("Application submitted successfully");
		}).catch((error) => {
			setError("Failed to submit form");
			console.error("Error submitting form:", error);
		}).finally(() => {
			setLoading(false);
		});
	};

	return (
		<div>
			{loading && <Loader />}
			<LeftMenu user={user} setUser={setUser} />
			<div className="application-form-container menu-right-container">
				<div className="w-100 mb-3">
					{error &&
						<div className="alert alert-danger w-100" role="alert">
							{error}
						</div>}
					{success &&
						<div className="alert alert-success w-100" role="alert">
							{success}
						</div>}

				</div>
				<form onSubmit={handleSubmit}>
					<h1>Application Form</h1>
					<hr />
					<div className="mb-3">
						<label htmlFor="username" className="form-label">Username</label>
						<input type="text" className="form-control" placeholder="Username" disabled
							name="username" id="username" value={formData.username} />
					</div>
					<div className="mb-3">
						<label htmlFor="znumber" className="form-label">Z-Number</label>
						<input type="text" className="form-control" placeholder="Z-Number"
							name="znumber" id="znumber" value={formData.znumber}
							onChange={handleChange}/>
					</div>
					<div className="mb-3">
						<label htmlFor="name" className="form-label">Name</label>
						<input type="text" className="form-control" placeholder="Name"
							name="name" id="name" value={formData.name}
							onChange={handleChange} />
					</div>
					<div className="mb-3">
						<label htmlFor="email" className="form-label">Email</label>
						<input type="email" className="form-control" placeholder="Email"
							name="email" id="email" value={formData.email}
							onChange={handleChange} />
					</div>
					<div className="mb-3">
						<label htmlFor="phoneNumber" className="form-label">Phone Number</label>
						<input type="text" className="form-control" placeholder="Phone Number"
							name="phoneNumber" id="phoneNumber" value={formData.phoneNumber}
							onChange={handleChange} />
					</div>
					<div className="mb-3">
						<label htmlFor="joiningDate" className="form-label">Joining Date</label>
						<input type="date" className="form-control" placeholder="Joining Date"
							name="joiningDate" id="joiningDate" value={formData.joiningDate}
							onChange={handleChange} />
					</div>

					<div className="mb-3">
						<input type="checkbox" className="form-check-input mr-3" name="preCourse"
							checked={preCourse} onChange={() => setPreCourse(!preCourse)} />
						<label htmlFor="previousCourses" className="form-label">Previous Courses</label>
						{preCourse &&
							<>
								{previousCourses.map((course, index) => (
									<div key={index} className="mb-3">
										<select className="form-select" name="previousCourses"
											value={course} onChange={(event) => handlePreviousCourseChange(event, index)}>
											{["", ...allPreviousCourses].map((course) => (
												<option key={course} value={course}>{course !== "" ? course : "Select Course"}</option>
											))}
										</select>
									</div>
								))}
								<button type="button" className="btn btn-warning" onClick={() => setPreviousCourses([...previousCourses, ""])}>
									Add
								</button>
							</>
						}
					</div>

					<div className="mb-3">
						<label htmlFor="eligibleCourses" className="form-label">Eligible Courses</label>
						{eligibleCourses.map((course, index) => (
							<div key={index} className="mb-3">
								<select className="form-select" name="eligibleCourses"
									onChange={(event) => handleEligibleCourseChange(event, index)}>
									{[{courseName: "", courseCode: ""}, ...availableCourses].map((course, idx) => (
										<option key={course.courseName} value={course.courseName}>
											{course.courseName === "" ? "Select Course" : <>({course.courseCode}) {course.courseName}</>}
										</option>
									))}
								</select>
							</div>
						))}
						<button type="button" className="btn btn-warning" onClick={() => setEligibleCourses([...eligibleCourses, ""])}>
							Add
						</button>
					</div>

					<div className="mb-3">
						<label htmlFor="resume" className="form-label">Resume</label>
						<input type="file" className="form-control" name="resume"
							onChange={handleFileChange} accept=".pdf" />
					</div>

					<button type="submit" className="btn btn-primary w-100">Submit</button>
				</form>
			</div>
		</div>
	);
};

export default ApplicationForm;
