import React, { useEffect, useState } from "react";
import axios from "../../utils/axios_util";
import { LeftMenu } from "./Utils";
import "../../styles/ApplicationList.css";
import Loader from "../Loader";

const ApplicationList = ({ setUser, user }) => {
	const [applications, setApplications] = useState([]);
	const [notifOpen, setNotifOpen] = useState(false);
	const [notifs, setNotifs] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [success, setSuccess] = useState("");

	const fillApplications = (apps) => {
		const newApps = [];
		apps.forEach((app) => {
			app.eligibleCourses.forEach((course, index) => {
				newApps.push({
					course,
					status: app.status[index],
					index,
					id: app.id,
				});
			});
		});

		setApplications(newApps);
	};

	useEffect(() => {
		setLoading(true);
		setError("");
		setSuccess("");
		axios.get(`/api/getApplicants?user=${user.username}`, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			},
		}).then((response) => {
			if (response.status === 200) {
				fillApplications(response.data);
			} else {
				setError("Failed to fetch applications.");
				console.error("Error fetching applications:", response.statusText);
			}
		}).catch((error) => {
			setError("Failed to fetch applications.");
			console.error("Error fetching applications:", error);
		}).finally(() => {
			setLoading(false);
		});

		setLoading(true);
		axios.get(`/api/notifications/${user.username}`, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			},
		})
			.then((response) => {
				if (response.status === 200) {
					setNotifs(response.data);
				} else {
					setError("Failed to fetch notifications.");
					console.error("Error fetching notifications:", response.statusText);
				}
			}).catch((error) => {
				setError("Failed to fetch notifications.");
				console.error("Error fetching notifications:", error);
			}).finally(() => {
				setLoading(false);
			});
	}, [user.username]);

	const getStatusBGColor = (status) => {
		switch (status) {
			case "Pending":
				return "warning";
			case "In Review":
				return "info";
			case "Accepted":
				return "success";
			case "Approved":
				return "secondary";
			case "Rejected":
				return "error";
			default:
				return "secondary";
		}
	};

	const handleAccept = async (id, index, i) => {
		setLoading(true);
		setError("");
		setSuccess("");
		axios.post("/api/updateStatus", {
			applicantId: id,
			index,
			newStatus: "Accepted",
		}, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			},
		}).then((response) => {
			if (response.status === 200) {
				const newApplications = [...applications];
				newApplications[i].status = "Accepted";
				setApplications(newApplications);
				setSuccess("Status updated successfully");
			} else {
				setError("Failed to update status");
			}
		}).catch((err) => {
			setError("Failed to update status");
			console.error("Error updating status:", err);
		}).finally(() => {
			setLoading(false);
		});
	};

	const handleNotifClose = async (id) => {
		setLoading(true);
		setError("");
		setSuccess("");
		axios.delete(`/api/notifications/${id}`, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			}
		}).then((response) => {
			if (response.status === 200) {
				const newNotifs = notifs.filter((notif) => notif.id !== id);
				setNotifs(newNotifs);
				setSuccess("Notification deleted successfully");
			} else {
				setError("Failed to delete notifications.");
			}
		}).catch((err) => {
			setError("Failed to delete notifications.");
			console.error("Error deleting notifications:", err);
		}).finally(() => {
			setLoading(false);
		});
	};

	return (
		<div>
			<LeftMenu user={user} setUser={setUser} />
			{loading && <Loader />}
			{!loading &&
				<div className="application-list-container">
					{error &&
						<div className="alert alert-danger" role="alert">
							{error}
						</div>
					}
					{success &&
						<div className="alert alert-success" role="alert">
							{success}
						</div>
					}

					<div className="d-flex align-center justify-content-between">
						<h1>Applications</h1>
						<div>
							<button type="button" className="btn btn-primary position-relative"
								onClick={() => setNotifOpen(notifOpen => !notifOpen)}>
								<i className="fa-solid fa-bell"></i>
								<span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
									{notifs.length}
								</span>
							</button>
						</div>
					</div>
					<hr/>

					<div className="mt-3">
						{applications.length !== 0 &&
							<div>
								<table className="table table-striped table-bordered">
									<thead>
										<tr>
											<th>Course Name</th>
											<th>Status</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										{applications.map((application, index) => (
											<tr key={index}>
												<td>{application.course}</td>
												<td>
													<span className={`badge bg-${getStatusBGColor(application.status)}`}>
														{application.status}
													</span>
												</td>
												<td>
													{application.status === "Approved" ?
														<button type="button" className="btn btn-success btn-sm"
															onClick={() => handleAccept(application.id, application.index, index)}>
															Accept
														</button> :
														<span className="badge bg-secondary">No action required</span>
													}
												</td>
											</tr>
										))}
									</tbody>
								</table>
							</div>}
							{applications.length === 0 &&
							<div className="alert alert-warning" role="alert">
								No applications found.
							</div>}
					</div>

					{notifOpen &&
						<div className="notifications-container">
							{notifs.map((notif, index) => {
								return (
									<div className="alert alert-info alert-dismissible fade show" role="alert" key={index}>
										{notif.message}
										<button type="button" className="btn-close"
											onClick={e => {
												e.preventDefault();
												handleNotifClose(notif.id);
											}}></button>
									</div>
								);
							})}
						</div>}
				</div>}
		</div>
	);
};

export default ApplicationList;
