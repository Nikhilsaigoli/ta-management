import React from "react";
import axios from "../../utils/axios_util";
import { NavLink, useNavigate } from "react-router-dom";
import '../../styles/LeftMenu.css';
import Loader from "../Loader";

const LeftMenu = ({ user, setUser }) => {
	const navigate = useNavigate();
	const [loading, setLoading] = React.useState(false);

	const handleLogout = async () => {
		try {
			setLoading(true);
			let token = localStorage.getItem("token");
			localStorage.removeItem("token");
			await axios.post("/api/logout", {}, {
				headers: {
					Authorization: token,
				}
			});
			setUser(null);
			navigate("/");
		} catch (error) {
			alert('There was a problem logging out. Please try again.');
			console.log(error);
		} finally {
			setLoading(false);
		}
	};

	function isActive(path) {
		return window.location.pathname === path;
	}

	let activeClasses = "menu-item menu-item-active";
	let inactiveClasses = "menu-item";

	return (
		<div>
			{loading && <Loader />}
			<div className="left-menu">
				<div className="d-flex flex-column align-items-center justify-content-center mb-5">
					<img src="https://www.w3schools.com/howto/img_avatar.png" alt="avatar"
						width="50" height="50" className="rounded-circle" />
					<p1>{user.username}</p1>
				</div>
				<div className={isActive("/") ? activeClasses : inactiveClasses}>
					<NavLink to={"/"}>All Feedbacks</NavLink>
				</div>
				<div className={isActive("/feedback") ? activeClasses : inactiveClasses}>
					<NavLink to={"/feedback"}>Fill Feedback</NavLink>
				</div>
				<div className="menu-item" onClick={handleLogout}>
					Log Out
				</div>
			</div>
		</div>
	);
};

export { LeftMenu };
