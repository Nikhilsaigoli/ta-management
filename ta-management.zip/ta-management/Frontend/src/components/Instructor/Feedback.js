import React, { useEffect, useState } from "react";
import { LeftMenu } from "./Utils";
import axios from "../../utils/axios_util";
import Loader from "../Loader";
import "../../styles/Feedback.css";

const UserFeedbackModal = ({ user, open, onClose, setError, setSuccess, setLoading }) => {
	const [feedback, setFeedback] = useState("");
	const [rating, setRating] = useState(0);
	const allowedRatings = [1, 2, 3, 4, 5];

	const handleClose = () => {
		setFeedback("");
		onClose();
	};

	const handleSubmit = () => {
		setError("");
		setSuccess("");
		setLoading(true);
		axios.post('/api/createFeedback', {
			...user,
			feedback,
			rating,
		}, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			}
		}).then(() => {
			setSuccess("Feedback created successfully");
			handleClose();
		}).catch((error) => {
			setError("Error creating feedback");
			console.error("Error creating feedback:", error);
		}).finally(() => {
			setLoading(false);
		});
	};

	const selectRating = (rating) => {
		let stars = document.getElementsByClassName("rating-star");
		for (let i = 0; i < stars.length; i++) {
			stars[i].style.color = "black";
		}
		for (let i = 0; i < rating; i++) {
			stars[i].style.color = "#FFD700";
		}
		setRating(rating);
	};

	return (
		<div>
			{open &&
			<div className="feedback-modal">
				<div className="modal-content">
					<div className="modal-header">
						<h5 className="modal-title">Feedback</h5>
					</div>
					<div className="modal-body">
						<form>
							<div className="row">
								<div className="col mb-3">
									<label htmlFor="username" className="form-label">Username</label>
									<input type="text" disabled id="username" className="form-control" value={user.username} />
								</div>
								<div className="col mb-3">
									<label htmlFor="name" className="form-label">Name</label>
									<input type="text" disabled id="name" className="form-control" value={user.name} />
								</div>
							</div>
							<div className="row">
								<div className="col mb-3">
									<label htmlFor="email" className="form-label">Email</label>
									<input type="email" disabled id="email" className="form-control" value={user.email} />
								</div>
								<div className="col mb-3">
									<label htmlFor="course" className="form-label">Course</label>
									<input type="text" disabled id="course" className="form-control" value={user.course} />
								</div>
							</div>
							<div className="mb-3">
								<label htmlFor="feedback" className="form-label">Feedback</label>
								<textarea id="feedback" className="form-control" value={feedback} onChange={(e) => setFeedback(e.target.value)}></textarea>
							</div>
							<div className="mb-3">
								<label htmlFor="rating" className="form-label">Rating</label>
								<div>
									{allowedRatings.map((rating) => (
										<span className="rating-star" key={rating}
											onClick={e => selectRating(rating)}>
											<i className="fa-solid fa-star" key={rating}></i>
										</span>
									))}
								</div>
							</div>
						</form>
					</div>
					<div className="modal-footer">
						<button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={onClose}>Cancel</button>
						<button type="button" className="btn btn-primary" onClick={handleSubmit}>Submit</button>
					</div>
				</div>
			</div>}
		</div>
	);
};

const Feedback = ({ user, setUser }) => {
	const [acceptedApplications, setAcceptedApplications] = useState([]);
	const [open, setOpen] = useState(false);
	const [error, setError] = useState("");
	const [success, setSuccess] = useState("");
	const [loading, setLoading] = useState(false);
	const [selectedUser, setSelectedUser] = useState({});

	const fillApplications = (apps) => {
		const newApplications = [];
		apps.forEach((app) => {
			app.eligibleCourses.forEach((course, index) => {
				if (app.status[index] === "Accepted") {
					newApplications.push({
						username: app.username,
						name: app.name,
						email: app.email,
						course,
					});
				}
			});
		});
		setAcceptedApplications(newApplications);
	};

	useEffect(() => {	
		setLoading(true);
		axios.get('/api/getAcceptedApplications', {
			headers: {
				"Authorization": localStorage.getItem("token"),
			}
		}).then((response) => {
			fillApplications(response.data);
		}).catch((error) => {
			setError("Failed to fetch accepted applications.");
			console.error("Error fetching accepted applications:", error);
		}).finally(() => {
			setLoading(false);
		});
	}, []);

	return (
		<div>
			{loading && <Loader />}
			<LeftMenu user={user} setUser={setUser} />
			<div className="menu-right-container">
				<div>
					{error && <div className="alert alert-danger">{error}</div>}
					{success && <div className="alert alert-success">{success}</div>}
				</div>
				<div>
					<h1>Users with eligible courses accepted</h1>
					<hr/>
					{acceptedApplications.length !== 0 && 
					<table className="table table-bordered table-striped">
						<thead>
							<tr>
								<th>Username</th>
								<th>Name</th>
								<th>Email</th>
								<th>Course</th>
								<th>Feedback</th>
							</tr>
						</thead>
						<tbody>
						{acceptedApplications.map((user, index) => (
							<tr key={index}>
								<td>{user.username}</td>
								<td>{user.name}</td>
								<td>{user.email}</td>
								<td>{user.course}</td>
								<td>
									<button className="btn btn-primary" onClick={() => {
										setOpen(true);
										setSelectedUser(user);
									}}>Feedback</button>
								</td>
							</tr>
						))}
						</tbody>
					</table>}
				</div>
			</div>
			<UserFeedbackModal
				user={selectedUser}
				open={open}
				onClose={() => setOpen(false)}
				setError={setError}
				setSuccess={setSuccess}
				setLoading={setLoading}
			/>
		</div>
	);
};

export default Feedback;
