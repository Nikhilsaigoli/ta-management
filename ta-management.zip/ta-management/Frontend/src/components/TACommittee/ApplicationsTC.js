import React, { useEffect } from "react";
import { useState } from "react";
import axios from "../../utils/axios_util";
import { LeftMenu } from "./Utils";
import Loader from "../Loader";

const ApplicationsTC = ({ user, setUser }) => {
	const [applications, setApplications] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [success, setSuccess] = useState("");

	const fillApplications = (apps) => {
		const newApplications = [];
		apps.forEach((app) => {
			app.eligibleCourses.forEach((course, index) => {
				if (app.status[index] === "In Review") {
					newApplications.push({
						...app,
						DSCourses: [course],
						index,
					});
				}
			});
		});
		setApplications(newApplications);
	};

	const handleApprove = async (id, index, i) => {
		setError("");
		setSuccess("");
		setLoading(true);
		axios.post("/api/updateStatus", {
			applicantId: id,
			index,
			newStatus: "Approved",
		}, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			}
		}).then((response) => {
			if (response.status === 200) {
				const newApplications = [...applications];
				newApplications[i].status = "Approved";
				setApplications(newApplications);
				setSuccess("Status updated successfully");
			} else {
				setError("Failed to update status");
			}
		}).catch((err) => {
				setError("Failed to update status");
				console.error("Error updating status:", err);
			}).finally(() => {
				setLoading(false);
			});
	};

	useEffect(() => {
		setLoading(true);
		setError("");
		setSuccess("");
		axios.get("/api/getApplicants", {
			headers: {
				"Authorization": localStorage.getItem("token"),
			},
		}).then((response) => {
			fillApplications(response.data);
			setLoading(false);
		}).catch((error) => {
			setError("Error fetching applicants");
			console.error("There was an error fetching the applicants:", error);
		}).finally(() => {
			setLoading(false);
		});
	}, []);

	const downloadFile = (name, filename) => {
		setLoading(true);
		setError("");
		setSuccess("");
		filename = filename.split("/")[1];
		axios.get(`/api/download-resume/${filename}`, {
			headers: {
				"Authorization": localStorage.getItem("token"),
			},
			responseType: "blob",
		}).then((response) => {
			const file = new Blob([response.data], {
				type: "application/octet-stream",
			});

			const downloadUrl = window.URL.createObjectURL(file);
			const link = document.createElement("a");
			link.href = downloadUrl;
			link.setAttribute("download", `${name}-resume.pdf`);
			document.body.appendChild(link);
			link.click();

			link.parentNode.removeChild(link);
			window.URL.revokeObjectURL(downloadUrl);
		}).catch((error) => {
			setError("Error downloading file");
			console.error("Error downloading file:", error);
		}).finally(() => {
			setLoading(false);
		});
	};

	return (
		<div>
			{loading && <Loader />}
			<LeftMenu user={user} setUser={setUser} />
			<div className="menu-right-container">
				<div>
					{error && <div className="alert alert-danger">{error}</div>}
					{success && <div className="alert alert-success">{success}</div>}
				</div>
				<h1>Applications</h1>
				<hr />
				{applications.length !== 0 && (
					<table className="table table-striped">
						<thead>
							<tr>
								<th>Z-Number</th>
								<th>Name</th>
								<th>Email</th>
								<th>Selected Courses</th>
								<th>Previous Courses</th>
								<th>Resume</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							{applications.filter(application => application.status.includes("In Review")).map((application, index) => (
								<tr key={index}>
									<td>{application.znumber}</td>
									<td>{application.name}</td>
									<td>{application.email}</td>
									<td>
										{application.DSCourses.map((course, index) => (
											<button className="btn btn-success m-1 btn-sm" key={index} disabled>{course}</button>
										))}
									</td>
									<td>
										{application.previousTACourses.map((course, index) => (
											<button className="btn btn-secondary m-1 btn-sm" key={index} disabled>{course}</button>
										))}
									</td>
									<td>
										<button className="btn btn-primary" onClick={() => downloadFile(application.name, application.resume)}>Download</button>
									</td>
									<td>
										<button className="btn btn-success" onClick={() => handleApprove(application.id, application.index, index)}>Approve</button>
									</td>
								</tr>
							))}
						</tbody>
					</table>
				)}
				{applications.length === 0 &&
					<div className="alert alert-warning">
						No applications to show
					</div>}
			</div>
		</div>
	);
};

export default ApplicationsTC;
