import React, { useEffect, useState } from "react";
import axios from "../utils/axios_util";
import { useNavigate } from "react-router-dom";
import Loader from "./Loader";
import '../styles/Login.css';

const Signup = ({ setUserGlobal }) => {
	const navigate = useNavigate();
	const [user, setUser] = useState({
		username: "",
		password: "",
		confirmPassword: "",
		role: "Student",
	});
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);

	useEffect(()=> {
		let startBtn = document.getElementById("start-btn");
		if (startBtn) {
			startBtn.click();
		}
	}, []);

	const handleSignUp = (event) => {
		// prevent default form submission
		event.preventDefault();
		event.stopPropagation();

		if (!user.username) {
			setError("Username is required.");
			return;
		}
		if (!user.password) {
			setError("Password is required.");
			return;
		}
		if (user.confirmPassword !== user.password) {
			setError("Passwords don't match.");
			return;
		}

		// password must be at least 8 characters long
		// and must contain at least one special character
		if (user.password.length < 8) {
			setError("Password must be at least 8 characters long.");
			return;
		}

		if (!/[!@#$%^&*]/.test(user.password)) {
			setError("Password must contain at least one special character.");
			return;
		}

		if (!user.role) {
			setError("Role is required.");
			return;
		}

		setLoading(true);
		setError("");
		axios
			.post("/api/signup", {
				username: user.username,
				password: user.password,
				role: user.role,
			})
			.then((res) => {
				localStorage.setItem("token", res.data.token);
				setUserGlobal({ username: res.data.username, role: res.data.role });
				navigate("/");
			})
			.catch((err) => {
				console.log(err);
				if (err.response && err.response.data) {
					setError(err.response.data);
				} else if (err.message) {
					setError(err.message);
				} else {
					setError("An error occurred. Please try again later");
				}
			})
			.finally(() => {
				setLoading(false);
			});
	};

	return (
		<div className="wrapper-container">
			<div id="particles-js"></div>
			{loading && <Loader />}
			<div className="login-container">
				{error &&
					<div className="alert alert-danger fade show" role="alert">
						{error}
					</div>}

				<h1>TA Management</h1>
				<div className="signInContainer">
					<h1>Sign Up</h1>
					<hr/>
					<form onSubmit={handleSignUp} method="post" action="/api/signup">
						<div className="mb-3">
							<label htmlFor="username" className="form-label">Username</label>
							<input type="text" className="form-control" placeholder="Username"
								name="username" id="username" value={user.username}
								onChange={e => setUser(user => {
									return {
										...user,
										username: e.target.value
									}
								})} />
						</div>
						<div className="mb-3">
							<label htmlFor="password" className="form-label">Password</label>
							<input type="password" className="form-control" id="password" name="password"
								placeholder="Password"
								value={user.password}
								onChange={e => setUser(user => {
									return {
										...user,
										password: e.target.value
									}
								})} />
						</div>
						<div className="mb-3">
							<label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
							<input type="password" className="form-control" id="confirmPassword" name="confirmPassword"
								placeholder="Confirm Password"
								value={user.confirmPassword}
								onChange={e => setUser(user => {
									return {
										...user,
										confirmPassword: e.target.value
									}
								})} />
						</div>
						<div className="mb-3">
							<label htmlFor="role" className="form-label">Role</label>
							<select className="form-select"
								id="role"
								value={user.role}
								onChange={e => setUser(user => {
									return {
										...user,
										role: e.target.value
									}
								})}>
								<option value="Student">Student</option>
								<option value="TA Committee Member">TA Committee Member</option>
								<option value="Department Staff">Department Staff</option>
								<option value="Instructor">Instructor</option>
							</select>
						</div>

						<button type="submit" className="btn btn-primary">Sign Up</button>
					</form>
					<p className="mt-3">Already have an account? <a href="/signin" onClick={e => {
						e.preventDefault();
						navigate("/signin");
					}}>Sign In</a></p>
				</div>
			</div>
		</div>
	);

	// return (
	// 	<Box className="signup-container d-flex flex-column align-items-center m-0 p-0">
	// 		<Typography
	// 			variant="h4"
	// 			component="h1"
	// 			className="text-center py-3"
	// 			style={{ fontFamily: "Holtwood One SC" }}
	// 		>
	// 			TA Management
	// 		</Typography>
	// 		<Box
	// 			style={{ backgroundColor: "white" }}
	// 			className="shadow py-2 px-5 signInContainer border mt-4 d-flex flex-column justify-content-center align-items-center"
	// 		>
	// 			<Box className="py-2">
	// 				<Typography
	// 					variant="h4"
	// 					component="h1"
	// 					gutterBottom
	// 					className="fw-bold"
	// 				>
	// 					Sign Up
	// 				</Typography>
	// 			</Box>
	// 			<Box className="my-2">
	// 				<TextField
	// 					label="Username"
	// 					variant="outlined"
	// 					fullWidth
	// 					name="username"
	// 					value={user.username}
	// 					onChange={handleChange}
	// 				/>
	// 			</Box>
	// 			<Box className="my-2">
	// 				<TextField
	// 					label="Password"
	// 					variant="outlined"
	// 					fullWidth
	// 					type="password"
	// 					name="password"
	// 					value={user.password}
	// 					onChange={handleChange}
	// 				/>
	// 			</Box>
	// 			<Box className="my-2">
	// 				<TextField
	// 					label="Confirm Password"
	// 					variant="outlined"
	// 					fullWidth
	// 					type="password"
	// 					name="confirmPassword"
	// 					value={user.confirmPassword}
	// 					onChange={handleChange}
	// 				/>
	// 			</Box>
	// 			<Box className="my-2">
	// 				<FormControl variant="outlined" fullWidth style={{ width: "300px" }}>
	// 					<InputLabel id="role-label">Role</InputLabel>
	// 					<Select
	// 						labelId="role-label"
	// 						label="Role"
	// 						name="role"
	// 						value={user.role}
	// 						onChange={handleChange}
	// 					>
	// 						<MenuItem value="Student">Student</MenuItem>
	// 						<MenuItem value="TA Committee Member">
	// 							TA Committee Member
	// 						</MenuItem>
	// 						<MenuItem value="Department Staff">Department Staff</MenuItem>
	// 						<MenuItem value="Instructor">Instructor</MenuItem>
	// 					</Select>
	// 				</FormControl>
	// 			</Box>

	// 			{error && (
	// 				<Box className="my-2">
	// 					<Alert severity="error">{error}</Alert>
	// 				</Box>
	// 			)}
	// 			<Box className="my-2">
	// 				<Button
	// 					variant="contained"
	// 					color="primary"
	// 					fullWidth
	// 					onClick={handleSignUp}
	// 				>
	// 					Sign Up
	// 				</Button>
	// 			</Box>
	// 		</Box>
	// 	</Box>
	// );
};

export default Signup;
