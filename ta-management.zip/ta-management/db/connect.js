require("dotenv").config();
const admin = require("firebase-admin");

const { SERVICEACCOUNTTOKEN } = process.env;

const serviceAccount = JSON.parse(SERVICEACCOUNTTOKEN);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();
if (!db) {
  console.error("Error connecting to the database");
  process.exit(1);
}

module.exports = db;
